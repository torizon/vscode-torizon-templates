import { NetworkDevice } from "../interfaces/NetworkDevice";
export declare class RemoteShellCommand {
    static shutdownDevice: typeof shutdownDevice;
    static rebootDevice: typeof rebootDevice;
    static getDockerDaemonJson: typeof getDockerDaemonJson;
    static getOSTreeDeploymentHash: typeof getOSTreeDeploymentHash;
    static getDeviceTreeOverlayList: typeof getDeviceTreeOverlayList;
    static getDeviceTreeOverlayApplied: typeof getDeviceTreeOverlayApplied;
    static applyDeviceTreeOverlays: typeof applyDeviceTreeOverlays;
}
export declare function shutdownDevice(dev: NetworkDevice, pswd: string, user: string): Promise<void>;
export declare function rebootDevice(dev: NetworkDevice, pswd: string, user: string): Promise<void>;
export declare function isDeviceIDEPaired(dev: NetworkDevice, pswd: string, user: string): Promise<boolean>;
export declare function getDockerDaemonJson(dev: NetworkDevice, pswd: string, user: string): Promise<object | null>;
export declare function getOSTreeDeploymentHash(dev: NetworkDevice, pswd: string, user: string): Promise<string>;
export declare function getDeviceTreeOverlayList(dev: NetworkDevice, pswd: string, user: string, ostreeHash: string): Promise<string[]>;
export declare function getDeviceTreeOverlayApplied(dev: NetworkDevice, pswd: string, user: string, ostreeHash: string): Promise<string[]>;
export declare function applyDeviceTreeOverlays(dev: NetworkDevice, pswd: string, user: string, overlays: string[], ostreeHash: string): Promise<void>;
export declare function machineEnv(dev: NetworkDevice, pswd: string, user: string): Promise<string>;
