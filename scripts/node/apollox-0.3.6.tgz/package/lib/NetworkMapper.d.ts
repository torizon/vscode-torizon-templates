interface NmapHost {
    ipAddress: string;
    state: 'up' | 'down';
    hostnames?: string[];
}
interface NmapResult {
    hosts: NmapHost[];
}
interface NmapScanOptions {
    target: string;
    scanType?: 'ping-scan';
    useSystemDns?: boolean;
    timing?: number;
    minParallelism?: number;
    maxRttTimeout?: number;
    maxRetries?: number;
}
export declare class NmapScan {
    private options;
    private target;
    private isValid;
    constructor(options: NmapScanOptions);
    run(): Promise<NmapResult>;
    private parseOutput;
    private static isValidTarget;
}
export {};
