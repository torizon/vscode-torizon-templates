import { NetworkDevice } from "./NetworkDevice";
export declare class TorizonDevice implements NetworkDevice {
    Hostname: string;
    Ip: string;
    SshPort: number;
    Version: string;
    Model: string;
    Machine: string;
    Login: string;
    Arch: string;
    Description: string;
    GetMachine(pswd: string): Promise<void>;
    Ping(): Promise<boolean>;
    Shutdown(pswd: string): Promise<void>;
    Reboot(pswd: string): Promise<void>;
    /**
     * @description Checks if the host ip has been changed since the last time
     * it was connected. We need to update the /etc/docker/daemon.json file
     * with the new ip address.
     */
    HostIpSanityCheck(hostIp: string, pswd: string, sshPort?: number, restartDocker?: boolean): Promise<boolean>;
}
