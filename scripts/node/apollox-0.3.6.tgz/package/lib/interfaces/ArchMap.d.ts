export declare class ArchMap {
    static readonly UNSUPPORTED: string;
    static readonly AMD64: string;
    static readonly ARM64: string;
    static readonly ARM32: string;
    static Table: {
        [key: string]: string;
    };
}
