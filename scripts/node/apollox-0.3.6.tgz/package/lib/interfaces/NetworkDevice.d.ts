export interface NetworkDevice {
    Hostname: string;
    Ip: string;
    SshPort: number;
    Description: string;
}
