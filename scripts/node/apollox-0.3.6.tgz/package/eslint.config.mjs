import typescriptEslint from "@typescript-eslint/eslint-plugin";
import spellcheck from "eslint-plugin-spellcheck";
import globals from "globals";
import tsParser from "@typescript-eslint/parser";
import path from "node:path";
import { fileURLToPath } from "node:url";
import js from "@eslint/js";
import { FlatCompat } from "@eslint/eslintrc";
import love from "eslint-config-love";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const compat = new FlatCompat({
    baseDirectory: __dirname,
    recommendedConfig: js.configs.recommended,
    allConfig: js.configs.all
});

export default [
    {
        ...love,

        files: [
            '**/*.ts'
        ],

        plugins: {
            "@typescript-eslint": typescriptEslint,
            spellcheck,
        },

        languageOptions: {
            globals: {
                ...globals.browser,
            },

            parser: tsParser,
            ecmaVersion: 12,
            sourceType: "module",

            parserOptions: {
                project: "tsconfig.json",
            },
        },

        rules: {
            "@typescript-eslint/semi": "off",
            "@typescript-eslint/quotes": "off",
            "@typescript-eslint/no-non-null-assertion": "off",
            "@typescript-eslint/member-delimiter-style": "off",
            "indent": [
                "error",
                4
            ],
            "max-len": [
                "error",
                {
                    "code": 80
                }
            ],
            "no-void": "off",
            complexity: [
                "warn",
                20
            ],
            semi: [
                2,
                "always"
            ],

            "spellcheck/spell-checker": ["error", {
                comments: false,
                strings: true,
                identifiers: false,
                templates: false,
                lang: "en_US",

                skipWords: [
                    "Torizon",
                    "torizon",
                    "git",
                    "ApolloX",
                    "binfmt",
                    "wsl",
                    "nmap",
                    "avahi",
                    "iputils",
                    "utf8",
                    "Toradex",
                    "workspace",
                    "yml",
                    "vscode",
                    "Dockerfile",
                ],

                minLength: 8,
            }],
        },
    }
];
