# Dependencies

> ⚠️ Make sure you have the following dependencies installed

- nmap
- avahi-utils
