import { TorizonDevice } from "./interfaces/TorizonDevice";
import { NetworkDevice } from "./interfaces/NetworkDevice";
export declare class DeviceDetection {
    NewDeviceFoundCallback: (device: NetworkDevice) => void;
    constructor(callback: (device: NetworkDevice) => void);
    ScanDevices(): Promise<NetworkDevice[]>;
    private static _hostNameIsIp;
    static GetNetworkDevices(_deviceFoundCallback?: ((device: NetworkDevice) => void) | undefined): Promise<NetworkDevice[]>;
    static ConnectToDevice(netDev: NetworkDevice, user: string, pswd: string, hostIp?: string, port?: number): Promise<TorizonDevice | undefined>;
}
