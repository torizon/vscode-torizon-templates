import { TorizonDevice } from "../interfaces/TorizonDevice";
export type voidFunc = () => void;
export type torizonDeviceCallback = (dev: TorizonDevice) => void;
export declare class EnvironmentCheck {
    static isWSL(): boolean;
    static isContainer(): boolean;
    static isDockerInstalled(): Promise<boolean>;
    static isDockerRunning(): Promise<boolean>;
    static isDockerComposeInstalled(): Promise<boolean>;
    static isPowerShellInstalled(): Promise<boolean>;
    static isPythonInstalled(): Promise<boolean>;
    static isPipxInstalled(): Promise<boolean>;
    static isXONSHInstalled(): Promise<boolean>;
    static isGitInstalled(): Promise<boolean>;
    static isNmapInstalled(): Promise<boolean>;
    static isAvahiInstalled(): Promise<boolean>;
    static isDigInstalled(): Promise<boolean>;
    static isIpUtilsPingInstalled(): Promise<boolean>;
    static isFileInstalled(): Promise<boolean>;
    static isSshpassInstalled(): Promise<boolean>;
    static isIproute2Installed(): Promise<boolean>;
    static isRsyncInstalled(): Promise<boolean>;
}
